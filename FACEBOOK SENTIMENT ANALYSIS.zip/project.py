import nltk
import matplotlib.pyplot as plt
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem.porter import PorterStemmer
from nltk.stem.wordnet import WordNetLemmatizer

# Load and preprocess text
with open('kindle.txt', encoding='ISO-8859-2') as f:
    text = f.read()

# Tokenization
print("Word Tokenization:\n", word_tokenize(text))
print("\nSentence Tokenization:\n", sent_tokenize(text))

# Stemming
porter_stemmer = PorterStemmer()
nltk_tokens = word_tokenize(text)
print("\nStemming Results:")
for w in nltk_tokens:
    print(f"Actual: {w} Stem: {porter_stemmer.stem(w)}")

# Lemmatization
wordnet_lemmatizer = WordNetLemmatizer()
print("\nLemmatization Results:")
for w in nltk_tokens:
    print(f"Actual: {w} Lemma: {wordnet_lemmatizer.lemmatize(w)}")

# POS Tagging
print("\nPOS Tagging:\n", nltk.pos_tag(nltk_tokens))

# Sentiment Analysis
sid = SentimentIntensityAnalyzer()

# Sentiment counters
positive_count = 0
negative_count = 0
neutral_count = 0
total_lines = 0

with open('kindle.txt', encoding='ISO-8859-2') as f:
    for line in f.read().split('\n'):
        if line.strip():  # Ignore empty lines
            total_lines += 1
            scores = sid.polarity_scores(line)
            compound = scores['compound']
            if compound >= 0.05:
                positive_count += 1
            elif compound <= -0.05:
                negative_count += 1
            else:
                neutral_count += 1

# 🧮 Percentage Calculations
positive_pct = (positive_count / total_lines) * 100
negative_pct = (negative_count / total_lines) * 100
neutral_pct = (neutral_count / total_lines) * 100

# 📢 Print Sentiment Summary
print("\n--- Sentiment Analysis Summary ---")
print(f"Total Lines Analyzed: {total_lines}")
print(f"Positive: {positive_count} ({positive_pct:.2f}%)")
print(f"Negative: {negative_count} ({negative_pct:.2f}%)")
print(f"Neutral: {neutral_count} ({neutral_pct:.2f}%)")

# 📊 Plotting the sentiment distribution
labels = ['Positive', 'Negative', 'Neutral']
values = [positive_count, negative_count, neutral_count]
colors = ['green', 'red', 'gray']

plt.figure(figsize=(8, 6))
plt.bar(labels, values, color=colors)
plt.title('Sentiment Distribution from kindle.txt')
plt.xlabel('Sentiment')
plt.ylabel('Number of Lines')
plt.grid(axis='y', linestyle='--', alpha=0.6)

# Adding value labels on top of each bar
for i, v in enumerate(values):
    plt.text(i, v + 1, str(v), ha='center', fontweight='bold')

plt.tight_layout()
plt.show()
